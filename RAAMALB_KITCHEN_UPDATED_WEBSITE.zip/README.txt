RAAMALB KITCHEN WEBSITE
Contents: index.html (responsive website), menu-poster.png (menu artwork).

PUBLISH WITH GITHUB PAGES
1. Extract this ZIP.
2. Open your GitHub repository: raamalb-kitchen.
3. Upload index.html and menu-poster.png to the repository root.
4. Commit the changes.
5. Open Settings > Pages.
6. Select Deploy from a branch, choose main and /(root), then Save.
7. Wait for GitHub Pages to publish; the public URL appears in Settings > Pages.

WhatsApp ordering: https://wa.me/2347066091104
